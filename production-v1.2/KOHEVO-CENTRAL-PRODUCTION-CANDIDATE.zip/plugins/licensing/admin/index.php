<?php
/**
 * Licensing — dashboard overview.
 */
require_once dirname(__DIR__, 3) . '/config.php';
require_once dirname(__DIR__) . '/LicensingAPI.php';
require_once dirname(__DIR__) . '/ModuleCatalog.php';
require_once dirname(__DIR__) . '/PlanService.php';
require_once dirname(__DIR__) . '/LicenseService.php';

Auth::require();
Auth::requirePerm('licensing.manage');
LicensingAPI::ensureSchema();

$pageTitle  = __('licensing_nav_dashboard', 'Licensing');
$currentNav = 'licensing';

$counts = [
    'products' => (int) Database::value("SELECT COUNT(*) FROM licensing_products"),
    'clients'  => (int) Database::value("SELECT COUNT(*) FROM licensing_clients"),
    'plans_active' => (int) Database::value("SELECT COUNT(*) FROM licensing_plans WHERE is_active = 1"),
    'plans_total'  => (int) Database::value("SELECT COUNT(*) FROM licensing_plans"),
    'bound_installations' => (int) Database::value("SELECT COUNT(*) FROM licensing_installations WHERE status = 'active'"),
    'active'   => (int) Database::value("SELECT COUNT(*) FROM licensing_installs WHERE status IN ('trial','active')"),
    'total'    => (int) Database::value("SELECT COUNT(*) FROM licensing_installs"),
    'checkins_24h' => (int) Database::value("SELECT COUNT(*) FROM licensing_checkins WHERE checked_at >= (UTC_TIMESTAMP() - INTERVAL 1 DAY)"),
    // Phase 2/3 schema (licensing_licenses) — separate from the legacy
    // licensing_installs counts above; see docs/02-architecture/
    // 13-MIGRATION-STRATEGY.md §4 for why both coexist.
    'licenses_active' => (int) Database::value("SELECT COUNT(*) FROM licensing_licenses WHERE status IN ('trial','active')"),
    'licenses_total'  => (int) Database::value("SELECT COUNT(*) FROM licensing_licenses"),
];
$hasKeypair = LicensingAPI::hasSigningKeypair();

$selectionCatalog = ModuleCatalog::selectionCatalog();
$infrastructureCatalog = ModuleCatalog::supportingInfrastructure();

$recentLicenses = Database::rows(
    "SELECT l.*, c.name AS client_name, p.name AS product_name,
            pl.name AS plan_name, pl.slug AS plan_slug,
            bi.installation_id AS bound_installation_id, bi.domain AS bound_domain
       FROM licensing_licenses l
       JOIN licensing_clients c  ON c.id = l.client_id
       JOIN licensing_products p ON p.id = l.product_id
  LEFT JOIN licensing_plans pl   ON pl.id = l.plan_id
  LEFT JOIN licensing_installations bi ON bi.license_id = l.id AND bi.status = 'active'
   ORDER BY l.created_at DESC, l.id DESC
      LIMIT 10"
);

$recentCheckins = Database::rows(
    "SELECT ck.*, i.label, i.domain, c.name AS client_name
       FROM licensing_checkins ck
       JOIN licensing_installs i ON i.id = ck.install_id
       JOIN licensing_clients c ON c.id = i.client_id
      ORDER BY ck.checked_at DESC LIMIT 10"
);

require SLATE_ROOT . '/admin/partials/header.php';
?>

<?php slate_breadcrumbs([
    ['label' => __('dashboard', 'Dashboard'), 'href' => SLATE_URL . '/admin/'],
    ['label' => __('licensing_nav_dashboard', 'Licensing')],
]); ?>

<div class="page-header">
    <div>
        <h1><?= __('licensing_nav_dashboard', 'Licensing') ?></h1>
        <p class="page-header-sub"><?= __('licensing_dashboard_sub', 'This install is a central license server — it issues and verifies licenses for other product installs.') ?></p>
    </div>
</div>

<?php if (!$hasKeypair): ?>
    <div class="alert alert-error" role="status">
        <?= __('licensing_no_keypair_warning', 'No signing keypair is provisioned yet — every check-in will fail. Run') ?>
        <code>php bin/licensing-generate-keys.php</code> <?= __('licensing_no_keypair_warning2', 'over SSH once.') ?>
    </div>
<?php endif; ?>

<div class="mcp-stats">
    <a class="stat-card" href="<?= e(plugin_url('licensing', 'admin/licenses.php')) ?>">
        <span class="stat-value"><?= (int) $counts['licenses_active'] ?> / <?= (int) $counts['licenses_total'] ?></span>
        <span class="stat-label"><?= __('licensing_active_licenses', 'Active / total licenses') ?></span>
    </a>
    <a class="stat-card" href="<?= e(plugin_url('licensing', 'admin/plans.php')) ?>">
        <span class="stat-value"><?= (int) $counts['plans_active'] ?> / <?= (int) $counts['plans_total'] ?></span>
        <span class="stat-label"><?= __('licensing_plans_nav', 'Active / total plans') ?></span>
    </a>
    <a class="stat-card" href="<?= e(plugin_url('licensing', 'admin/licenses.php')) ?>">
        <span class="stat-value"><?= (int) $counts['bound_installations'] ?></span>
        <span class="stat-label"><?= __('licensing_bound_installations', 'Bound installations') ?></span>
    </a>
    <a class="stat-card" href="<?= e(plugin_url('licensing', 'admin/products.php')) ?>">
        <span class="stat-value"><?= (int) $counts['products'] ?></span>
        <span class="stat-label"><?= __('licensing_products_nav', 'Products') ?></span>
    </a>
    <a class="stat-card" href="<?= e(plugin_url('licensing', 'admin/clients.php')) ?>">
        <span class="stat-value"><?= (int) $counts['clients'] ?></span>
        <span class="stat-label"><?= __('licensing_clients_nav', 'Clients') ?></span>
    </a>
    <a class="stat-card" href="<?= e(plugin_url('licensing', 'admin/installs.php')) ?>">
        <span class="stat-value"><?= (int) $counts['active'] ?> / <?= (int) $counts['total'] ?></span>
        <span class="stat-label"><?= __('licensing_active_licenses_legacy', 'Active / total (legacy)') ?></span>
    </a>
    <div class="stat-card">
        <span class="stat-value"><?= (int) $counts['checkins_24h'] ?></span>
        <span class="stat-label"><?= __('licensing_checkins_24h', 'Check-ins (24h)') ?></span>
    </div>
</div>

<section class="card mt-3">
    <div class="card-header"><h2><?= e(__('licensing_module_catalog_heading', 'Commercial Module Catalog')) ?></h2></div>
    <table class="table">
        <thead>
            <tr>
                <th><?= e(__('licensing_col_module', 'Module')) ?></th>
                <th><?= e(__('licensing_col_key', 'Entitlement Key')) ?></th>
                <th><?= e(__('licensing_col_plugin', 'Plugin Slug')) ?></th>
                <th><?= e(__('licensing_col_status', 'Classification')) ?></th>
                <th><?= e(__('licensing_col_dependencies', 'Infrastructure Dependencies')) ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($selectionCatalog as $mKey => $mMeta): ?>
                <tr>
                    <td>
                        <strong><?= e($mMeta['display_name']) ?></strong>
                        <div class="text-muted" style="font-size:12px"><?= e($mMeta['description']) ?></div>
                    </td>
                    <td><code><?= e($mKey) ?></code></td>
                    <td><code><?= e($mMeta['plugin_identifier']) ?></code></td>
                    <td>
                        <?php if (!empty($mMeta['v1_available'])): ?>
                            <span class="badge badge-success">V1 Commercial</span>
                        <?php else: ?>
                            <span class="badge">Not V1 / Future</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (!empty($mMeta['dependencies'])): ?>
                            <code><?= e(implode(', ', $mMeta['dependencies'])) ?></code>
                        <?php else: ?>
                            <span class="text-muted">None</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php foreach ($infrastructureCatalog as $iKey => $iMeta): ?>
                <tr>
                    <td>
                        <strong><?= e($iMeta['display_name']) ?></strong>
                        <div class="text-muted" style="font-size:12px"><?= e($iMeta['description']) ?></div>
                    </td>
                    <td><span class="text-muted">N/A (auto-provisioned)</span></td>
                    <td><code><?= e($iMeta['plugin_identifier']) ?></code></td>
                    <td><span class="badge">Supporting Infrastructure</span></td>
                    <td><span class="text-muted">Auto-enabled for Membership / Booking</span></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</section>

<section class="card mt-3">
    <div class="card-header"><h2><?= e(__('licensing_recent_licenses_heading', 'Commercial Licenses & Entitlements')) ?></h2></div>
    <?php if (!$recentLicenses): ?>
        <p class="text-muted"><?= e(__('licensing_no_licenses', 'No licenses issued yet.')) ?></p>
    <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th><?= e(__('licensing_col_label', 'License')) ?></th>
                    <th><?= e(__('licensing_col_client', 'Client')) ?></th>
                    <th><?= e(__('licensing_col_plan', 'Plan')) ?></th>
                    <th><?= e(__('licensing_col_status', 'Status')) ?></th>
                    <th><?= e(__('licensing_col_installation', 'Bound Installation')) ?></th>
                    <th><?= e(__('licensing_col_modules', 'Entitlements')) ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentLicenses as $lic):
                    $licModules = LicenseService::modules((int) $lic['id']);
                ?>
                    <tr>
                        <td>
                            <a href="<?= e(plugin_url('licensing', 'admin/license.php?id=' . (int) $lic['id'])) ?>">
                                <strong><?= e($lic['label'] ?: ('License #' . (int) $lic['id'])) ?></strong>
                            </a>
                        </td>
                        <td><?= e($lic['client_name']) ?></td>
                        <td><?= $lic['plan_name'] ? e($lic['plan_name']) : '<span class="text-muted">—</span>' ?></td>
                        <td><span class="badge"><?= e($lic['status']) ?></span></td>
                        <td>
                            <?php if (!empty($lic['bound_installation_id'])): ?>
                                <code><?= e($lic['bound_domain'] ?: $lic['bound_installation_id']) ?></code>
                            <?php else: ?>
                                <span class="text-muted">Unbound</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($licModules): ?>
                                <code><?= e(implode(', ', $licModules)) ?></code>
                            <?php else: ?>
                                <span class="text-muted">Core only</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>

<section class="card mt-3">
    <div class="card-header"><h2><?= e(__('licensing_recent_checkins', 'Recent check-ins')) ?></h2></div>
    <?php if (!$recentCheckins): ?>
        <p class="text-muted"><?= e(__('licensing_no_checkins', 'No check-ins recorded yet.')) ?></p>
    <?php else: ?>
        <div class="data-list">
            <?php foreach ($recentCheckins as $ck): ?>
                <div class="mcp-row">
                    <div>
                        <strong><?= e($ck['label'] ?: $ck['domain']) ?> — <?= e($ck['client_name']) ?></strong>
                        <span><?= e($ck['checked_at']) ?> · <?= e($ck['response_status']) ?> · <?= e($ck['ip'] ?: '—') ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<style>
.mcp-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:16px}
.stat-card{display:flex;flex-direction:column;gap:4px;padding:18px;border:1px solid var(--border,#e5e7eb);border-radius:10px;text-decoration:none;color:inherit}
.stat-value{font-size:1.6rem;font-weight:700}
.stat-label{font-size:.82rem;color:var(--muted,#6b7280)}
.mcp-row{display:flex;justify-content:space-between;align-items:center;gap:16px;border-top:1px solid var(--border,#e5e7eb);padding:14px 0}
.mcp-row:first-child{border-top:0}
.mcp-row strong,.mcp-row span{display:block}
.mcp-row span{margin-top:4px;font-size:.82rem;color:var(--muted,#6b7280)}
@media(max-width:720px){.mcp-stats{grid-template-columns:repeat(2,1fr)}}
</style>

<?php require SLATE_ROOT . '/admin/partials/footer.php'; ?>
