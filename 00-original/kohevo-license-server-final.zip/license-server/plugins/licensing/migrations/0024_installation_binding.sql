-- Phase 2: bind a license to durable installation identities.
-- Existing licensing_installs rows remain valid; domain_normalized is backfilled
-- by the application on first use so legacy data is observable and safe.
ALTER TABLE `licensing_installs`
    ADD COLUMN IF NOT EXISTS `domain_normalized` VARCHAR(190) NULL AFTER `domain`,
    ADD KEY IF NOT EXISTS `idx_install_domain_normalized` (`product_id`, `domain_normalized`);

CREATE TABLE IF NOT EXISTS `licensing_installation_bindings` (
    `id`                  INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `install_id`          INT UNSIGNED NOT NULL,
    `installation_id`     CHAR(32) NOT NULL,
    `domain_normalized`   VARCHAR(190) NOT NULL,
    `first_registered_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `last_seen_at`        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `last_seen_ip`        VARCHAR(45) NULL,
    `status`              ENUM('active','suspended','revoked','cancelled') NOT NULL DEFAULT 'active',
    `created_at`          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uniq_binding_install_identity` (`install_id`, `installation_id`),
    UNIQUE KEY `uniq_binding_identity` (`installation_id`),
    KEY `idx_binding_install` (`install_id`),
    CONSTRAINT `fk_binding_install` FOREIGN KEY (`install_id`) REFERENCES `licensing_installs`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `licensing_checkins`
    ADD COLUMN IF NOT EXISTS `failure_code` VARCHAR(64) NULL AFTER `response_status`,
    ADD KEY IF NOT EXISTS `idx_checkin_failure` (`failure_code`);
